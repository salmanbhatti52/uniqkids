import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-otp',
  templateUrl: './otp.page.html',
  styleUrls: ['./otp.page.scss'],
})
export class OtpPage implements OnInit {

  constructor(public navCtrl: NavController) { }

  ngOnInit() {
  }

   next(e, elNext, elBack) {
    console.log(e);
    console.log(e.keyCode);
    if (e.keyCode === 8 || e.keyCode === 229) {
      elBack.setFocus();
    } else {
      elNext.setFocus();
    }
  }

  goback(){
    this.navCtrl.navigateRoot('/forgotpassword');
  }
  resetpass(){
    this.navCtrl.navigateRoot('/resetpassword');
  }

}
